<?php
// Heading
$_['heading_title']                     = '綠界物流';

// Text
$_['text_unimart']                      = '統一超商取貨';
$_['text_unimart_collection']           = '統一超商取貨付款';
$_['text_fami']                         = '全家超商取貨';
$_['text_fami_collection']              = '全家超商取貨付款';
$_['text_hilife']                       = '萊爾富超商取貨';
$_['text_hilife_collection']            = '萊爾富超商取貨付款';
$_['text_okmart']                       = 'OK超商取貨';
$_['text_okmart_collection']            = 'OK超商取貨付款';
$_['text_post']                         = '中華郵政';
$_['text_tcat']                         = '黑貓宅配';
$_['text_choice']                       = '選擇收件門市';
$_['text_rechoice']                     = '重新選擇收件門市';
$_['text_store_name']                   = '門市名稱：';
$_['text_store_address']                = '門市地址：';
$_['text_store_tel']                    = '門市電話：';
$_['text_store_info']                   = '收件門市';
$_['text_telephone']                    = '收件人電話';
$_['No special symbols are allowed in the phone number, it must be ten digits long and start with 09']  = '電話號碼不允許使用特殊符號，長度必須為十碼且為09開頭';

// Error
$_['error_no_storeinfo']                = '尚未選擇收件門市';