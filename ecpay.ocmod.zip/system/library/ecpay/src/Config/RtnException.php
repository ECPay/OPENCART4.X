<?php

return [
    102 => 'Generate CheckMacValue failed',
    103 => 'Response is not JSON format',
    104 => 'Class with hash do not exist',
    105 => 'Get response failed',
    106 => 'CheckMacValue verify failed',
    107 => 'cURL initialize failed',
    108 => 'Perform cURL session failed',
    109 => 'AES decrypt failed',
    110 => 'AES encrypt failed',
    111 => 'JSON decrypt failed',

];
